#include <bits/stdc++.h>

using namespace std;
char s[1000];

int main(){
	freopen("test.asm", "r", stdin);
	freopen("test1.asm", "w", stdout);
	while(gets(s) != NULL){
		printf("%s\n", s);
		printf("nop\nnop\nnop\nnop\n");
	}
} 
